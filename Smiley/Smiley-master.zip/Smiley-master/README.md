# Smiley
https://github.com/ehubin/Adafruit-GFX-Library/tree/master/Img2Code
